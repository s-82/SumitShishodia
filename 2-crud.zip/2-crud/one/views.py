from django.shortcuts import render,redirect,HttpResponse
from .models import Data

# Create your views here.
def display(request):
    data=Data.objects.all()
    return render(request,'display.html',{'data':data})


def insert(request):
    if(request.method=='POST'):
        eid=request.POST.get('eid')
        name=request.POST.get('name')
        department=request.POST.get('department')
        salary=request.POST.get('salary')

        info=Data.objects.create(eid=eid,name=name,department=department,salary=salary)
        info.save()
        return(redirect('display'))
    return(render(request,'insert.html'))
  

def deletee(request,eid):
    Data.objects.filter(eid=eid).delete()
    return(redirect('display'))


def edit(request,eid):
    if(request.method=='POST'):
        name=request.POST.get('name')
        department=request.POST.get('department')
        salary=request.POST.get('salary')
        Data.objects.filter(eid=eid).update(name=name,department=department,salary=salary)
        return(redirect('display'))
    info=Data.objects.filter(eid=eid)
    return(render(request,'edit.html',{'data':info}))