from django.db import models

# Create your models here.
class Data(models.Model):
    eid=models.IntegerField()
    name=models.CharField(max_length=20)
    salary=models.IntegerField()
    department=models.CharField(max_length=30)

    def __str__(self):
        return(self.name)

