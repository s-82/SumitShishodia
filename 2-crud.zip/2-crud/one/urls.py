from django.urls import path
from .views import *
urlpatterns = [
    path("",display,name='display'),
    path("insert/",insert,name='insert'),
    path('del/<int:eid>',deletee,name='deletee'),
    path('edit/<int:eid>',edit,name='edit')
 ]
