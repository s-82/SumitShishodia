from django.shortcuts import render,HttpResponse
from .forms import UserForm
# Create your views here.


def create_user(request):
    if request.method=='POST':
        form=UserForm(request.POST)
        if form.is_valid():
            form.save()
    else:
            form=UserForm()
    return render(request,'index.html',{'form':form})
     
def home(request):
    return HttpResponse('Hello word')
