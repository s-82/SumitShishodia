from django.urls import path
from .import views
urlpatterns = [
    
    path('home/',views.home,name='home'),
    path('create/',views.create_user,name='create_user')
]
