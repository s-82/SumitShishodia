from django.db import models
from django.core.validators import validate_email

# Create your models here.
class User(models.Model):
    name=models.CharField(max_length=30)
    email=models.EmailField(validators=[validate_email])

    def __str__(self):
        return self .name